import mongoose from "mongoose";
import bcrypt from "bcrypt";
import { parse } from "dotenv";

const userSchema = new mongoose.Schema(
  {
    username: {
      type: String,
      required: [true, "username is required"],
      unique: true,
      trim: true,
    },
    fullName: {
      type: String,
      required: [true, "username is required"],
      trim: true,
    },
    email: {
      type: String,
      required: [true, "email is required"],
      unique: true,
      trim: true,
    },
    password: {
      type: String,
      minlength:8
    },
    mobile: {
      type: String,
      unique: true,
      trim: true,
      minlength: 10,
      maxlength: 10,
    },
    followers: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "users",
      },
    ],
    followings: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "users",
      },
    ],
    posts: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "posts",
      },
    ],
    comments: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "comments",
      },
    ],
    stories: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "stories",
      },
    ],
    bio: {
      type: String,
    },
    dob: {
      type: Date,
    },
    reels: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "reels",
      },
    ],
    profile_pic: {
      type: String,
    },
    saves: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "posts",
      },
    ],
    googleId:{
      type:String,
      unique:true,
      sparse:true,
    },
    authProvider:{
      type:String,
      enum:["local","google"],
      default:"local"
    }

  },
  {
    timestamps: true,
  }
);

userSchema.pre("save", async function () {
  if (!this.isModified("password")) return;

  this.password = await bcrypt.hash(this.password, 10);
});
userSchema.methods.comparePass = function (password) {
  return bcrypt.compareSync(password, this.password);
};

const UserModel = mongoose.model("users", userSchema);
export default UserModel;
